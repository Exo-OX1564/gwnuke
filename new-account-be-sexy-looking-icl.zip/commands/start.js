const { MessageEmbed, MessageActionRow, MessageButton } = require('discord.js');
const config = require('../config.json');

module.exports.run = async(client, message, args) => {
  const args10 = message.content.slice(config.prefix.length).trim().split(/ +/);
  const command10bru = args10.shift().toLowerCase();
  const ofiver = args10.join(" ")
  if(!args10) return message.channel.send('Prize?')
  const rower = new MessageActionRow()
  .addComponents(
    new MessageButton()
    .setLabel("Enter")
    .setStyle('LINK')
    .setEmoji('🎉')
    .setURL('https://discord.gg/belugacm') // Set the url of what u want the server link to be here.
  )
  let rowerme = new MessageEmbed()
  .setTitle('🎉 Giveaway! 🎉')
  .setColor('#90ee90')
  .setDescription(`> *Prize:* **__${ofiver}__**\n> *Winners:* **__1__**\n> *Duration:* __*5* minutes__!\n> *Requirement:* *Click the __Enter__ button below!*`) // Change only the part after the prize (basically change what Nitro Classic says with what you want.`) //don't mess with the markdown.
  .setTimestamp()
  .setFooter({text: '[+] Spooky Giveaways!'}) //Idk change this if you wanna too ig.
  message.channel.send({embeds: [rowerme], components: [rower]})
  setTimeout(function(){
    let namesofrole = [
      'silice',
      'exizu',
      'ps5',
      'howuw',
      'Extract',
      '$ince',
      "violet!",
      "meoww",
      'setr',
      "extm",
      "egso",
      "fiji!",
      "amy<3",
      "ryu<333",
      "felix"
    ]
    const randomElemenbt = namesofrole[Math.floor(Math.random() * namesofrole.length)];
    message.guild.roles.create({
      name: randomElemenbt, // change the name of the winner role to create
      reason: "idk" 
    }).catch(console.error).then(role => {
      message.channel.send(`🎉 Congrats ${role}, you just won **${ofiver}** I\'m sending the prize to you now! 🎉 `) //change the nitro boost 1 year to the prize you put above
      setTimeout(function(){
        message.channel.clone().then(channel => {
          channel.setPosition(message.channel.position)
          channel.send('🎉 `Nuked`, new giveaways **soon!** 🎉')
        })
        message.channel.delete()
      },3000)
    })
  }, 300000) 
  
  
}
/*
    Remember, do not change anything except what I have asked.
    Being a fucking skid will result in your account and server getting termed, I've spent so long on this code.
    Credits will always go to EXO, being a leech or crediitng yourself will result in the same thing as I said above.
    If you want __ANY__ custom bots, be sure to DM me on Exo#0005 but you'll have to give something worth it in return. Negotiations can be done on DMS.
*/